# Northwind CRM
React 18 + TypeScript + Redux Toolkit + Tailwind + Recharts (Vite).
`npm install` · `npm run dev` · `npm test` · `npm run build`
Data is seeded in `src/data/seed.ts` and served through the `loadCrm` thunk in `src/store/crmSlice.ts`; replace that thunk body with your API call.
