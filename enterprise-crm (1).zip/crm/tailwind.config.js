export default { content: ['./index.html','./src/**/*.{ts,tsx}'],
 theme:{extend:{colors:{ink:'#12343b',paper:'#f5f6f2',brand:'#d98e04',line:'#dfe3da'},fontFamily:{sans:['"Schibsted Grotesk"','system-ui','sans-serif']}}}}
