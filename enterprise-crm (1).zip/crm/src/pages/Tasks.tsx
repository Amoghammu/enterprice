import { useState } from 'react'
import { Badge, Empty, Field, Modal, PageHead, uid } from '../components/ui'
import { team } from '../data/seed'
import { useAppDispatch, useAppSelector } from '../store'
import { saveTask, toggleTask } from '../store/crmSlice'
import { PRIORITIES, Priority } from '../types'
export default function Tasks() {
  const d = useAppDispatch(); const tasks = useAppSelector(s => s.crm.tasks); const [open, setOpen] = useState(false)
  const [f, setF] = useState({ title: '', assignee: team[0], priority: 'Medium' as Priority, due: '' }); const [e, setE] = useState<Record<string, string>>({})
  const submit = (ev: React.FormEvent) => { ev.preventDefault(); const er: Record<string, string> = {}
    if (f.title.trim().length < 3) er.title = 'Describe the task (3+ characters).'; if (!f.due) er.due = 'Pick a deadline.'; setE(er)
    if (!Object.keys(er).length) { d(saveTask({ id: uid(), ...f, done: false })); setOpen(false); setF({ ...f, title: '', due: '' }) } }
  const sorted = [...tasks].sort((a, b) => Number(a.done) - Number(b.done) || a.due.localeCompare(b.due))
  const today = new Date().toISOString().slice(0, 10)
  return <><PageHead title="Tasks" action={<button className="btn" onClick={() => setOpen(true)}>New task</button>} />
    <ul className="divide-y divide-line rounded-lg border border-line bg-white">{sorted.map(t => <li key={t.id} className="item-in flex items-center gap-3 p-4 transition-colors hover:bg-paper">
      <input type="checkbox" aria-label={`Complete ${t.title}`} checked={t.done} onChange={() => d(toggleTask(t.id))} className="h-5 w-5 accent-[#12343b]" />
      <div className="min-w-0 flex-1"><p className={`transition-all duration-300 ${t.done ? 'line-through opacity-50' : 'font-medium'}`}>{t.title}</p><p className="text-sm text-ink/60">{t.assignee} · <span className={!t.done && t.due < today ? 'font-medium text-red-700' : ''}>Due {t.due}</span></p></div><Badge label={t.priority} /></li>)}</ul>
    {!tasks.length && <Empty text="No tasks. Create one to get started." />}
    {open && <Modal title="New task" onClose={() => setOpen(false)}><form onSubmit={submit} noValidate className="space-y-3">
      <Field label="Title" error={e.title}><input className="input" value={f.title} onChange={x => setF({ ...f, title: x.target.value })} /></Field>
      <Field label="Assignee"><select className="input" value={f.assignee} onChange={x => setF({ ...f, assignee: x.target.value })}>{team.map(t => <option key={t}>{t}</option>)}</select></Field>
      <Field label="Priority"><select className="input" value={f.priority} onChange={x => setF({ ...f, priority: x.target.value as Priority })}>{PRIORITIES.map(p => <option key={p}>{p}</option>)}</select></Field>
      <Field label="Deadline" error={e.due}><input type="date" className="input" value={f.due} onChange={x => setF({ ...f, due: x.target.value })} /></Field>
      <button className="btn w-full">Create task</button></form></Modal>}</>
}
