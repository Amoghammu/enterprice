import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { CountUp, PageHead, money } from '../components/ui'
import { revenue } from '../data/seed'
import { useAppSelector } from '../store'
import { LEAD_STATUSES, STAGES } from '../types'
export default function Dashboard() {
  const { leads, deals, tasks } = useAppSelector(s => s.crm)
  const won = leads.filter(l => l.status === 'Won').length
  const open = deals.filter(d => d.stage !== 'Won').reduce((a, d) => a + d.value, 0)
  const stats: [string, number, (n: number) => string][] = [['Total leads', leads.length, String], ['Open pipeline', open, money], ['Won revenue', deals.filter(d => d.stage === 'Won').reduce((a, d) => a + d.value, 0), money], ['Lead conversion', leads.length ? Math.round(won / leads.length * 100) : 0, n => n + '%'], ['Open tasks', tasks.filter(t => !t.done).length, String]]
  const byStatus = LEAD_STATUSES.map(s => ({ name: s, count: leads.filter(l => l.status === s).length }))
  const byStage = STAGES.map(s => ({ name: s, value: deals.filter(d => d.stage === s).reduce((a, d) => a + d.value, 0) }))
  return <><PageHead title="Dashboard" />
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">{stats.map(([l, v, f], i) => <div key={l} style={{ animationDelay: `${i * 70}ms` }} className="rise card-lift rounded-lg border border-line bg-white p-4"><p className="text-sm text-ink/60">{l}</p><p className="mt-1 text-2xl font-bold tabular-nums"><CountUp to={v} format={f} /></p></div>)}</div>
    <div className="mt-4 grid gap-4 lg:grid-cols-2">
      <Chart title="Monthly revenue ($k)"><LineChart data={revenue}><CartesianGrid stroke="#dfe3da" vertical={false} /><XAxis dataKey="m" /><YAxis /><Tooltip /><Line dataKey="v" stroke="#d98e04" strokeWidth={3} dot={false} /></LineChart></Chart>
      <Chart title="Leads by status"><BarChart data={byStatus}><CartesianGrid stroke="#dfe3da" vertical={false} /><XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="count" fill="#12343b" radius={[4, 4, 0, 0]} /></BarChart></Chart>
      <Chart title="Deal value by stage"><BarChart data={byStage}><CartesianGrid stroke="#dfe3da" vertical={false} /><XAxis dataKey="name" /><YAxis /><Tooltip formatter={(v: number) => money(v)} /><Bar dataKey="value" fill="#d98e04" radius={[4, 4, 0, 0]} /></BarChart></Chart></div></>
}
const Chart = ({ title, children }: { title: string; children: React.ReactElement }) => <section className="rise rounded-lg border border-line bg-white p-4" style={{ animationDelay: '350ms' }}><h2 className="mb-3 font-bold">{title}</h2><div className="h-64"><ResponsiveContainer>{children}</ResponsiveContainer></div></section>
