import { useState } from 'react'
import ActivityForm from '../components/ActivityForm'
import { Empty, Modal, PageHead } from '../components/ui'
import { useAppSelector } from '../store'
import { ACTIVITY_TYPES } from '../types'
export default function Activities() {
  const { activities, customers } = useAppSelector(s => s.crm); const [type, setType] = useState(''); const [open, setOpen] = useState(false)
  const rows = activities.filter(a => !type || a.type === type).sort((a, b) => b.date.localeCompare(a.date))
  return <><PageHead title="Activities" action={<button className="btn" onClick={() => setOpen(true)}>Log activity</button>} />
    <select aria-label="Filter by type" className="input mb-3 w-auto" value={type} onChange={e => setType(e.target.value)}><option value="">All types</option>{ACTIVITY_TYPES.map(t => <option key={t}>{t}</option>)}</select>
    <ul className="divide-y divide-line rounded-lg border border-line bg-white">{rows.map(a => <li key={a.id} className="item-in p-4 transition-colors hover:bg-paper"><p className="text-sm"><b>{a.type}</b> with {customers.find(c => c.id === a.customerId)?.name} · {a.date}</p><p className="text-sm text-ink/70">{a.note}</p></li>)}</ul>
    {!rows.length && <Empty text="No activities of this type yet." />}
    {open && <Modal title="Log activity" onClose={() => setOpen(false)}><ActivityForm onDone={() => setOpen(false)} /></Modal>}</>
}
