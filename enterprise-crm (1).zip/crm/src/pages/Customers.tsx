import { useState } from 'react'
import ActivityForm from '../components/ActivityForm'
import { Empty, Modal, PageHead, money } from '../components/ui'
import { useAppSelector } from '../store'
export default function Customers() {
  const { customers, activities, deals } = useAppSelector(s => s.crm)
  const [sel, setSel] = useState(customers[0]?.id); const [log, setLog] = useState(false)
  const c = customers.find(x => x.id === sel)
  const hist = activities.filter(a => a.customerId === sel).sort((a, b) => b.date.localeCompare(a.date))
  return <><PageHead title="Customers" /><div className="grid gap-4 lg:grid-cols-[18rem_1fr]">
    <ul className="space-y-1">{customers.map(x => <li key={x.id}><button onClick={() => setSel(x.id)} aria-current={x.id === sel} className={`card-lift w-full rounded-md border px-3 py-2 text-left ${x.id === sel ? 'border-ink bg-white' : 'border-line'}`}><span className="block font-medium">{x.name}</span><span className="text-sm text-ink/60">{x.company}</span></button></li>)}</ul>
    {c ? <section key={c.id} className="fade-in rounded-lg border border-line bg-white p-5">
      <h2 className="text-xl font-bold">{c.name}</h2><p className="text-ink/60">{c.company} · {c.city}</p>
      <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-3"><div><dt className="text-ink/60">Email</dt><dd><a className="underline" href={`mailto:${c.email}`}>{c.email}</a></dd></div><div><dt className="text-ink/60">Phone</dt><dd>{c.phone}</dd></div>
        <div><dt className="text-ink/60">Deal value</dt><dd>{money(deals.filter(d => d.customerId === c.id).reduce((a, d) => a + d.value, 0))}</dd></div></dl>
      <div className="mt-6 flex items-center justify-between"><h3 className="font-bold">Interaction history</h3><button className="btn-ghost" onClick={() => setLog(true)}>Log activity</button></div>
      <ol className="mt-3 space-y-3 border-l-2 border-line pl-4">{hist.map(a => <li key={a.id} className="item-in"><p className="text-sm"><b>{a.type}</b> · {a.date}</p><p className="text-sm text-ink/70">{a.note}</p></li>)}</ol>
      {!hist.length && <Empty text="No interactions yet. Log a call, meeting, or email." />}
      {log && <Modal title="Log activity" onClose={() => setLog(false)}><ActivityForm customerId={c.id} onDone={() => setLog(false)} /></Modal>}</section> : <Empty text="No customers yet." />}</div></>
}
