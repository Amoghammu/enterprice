import { useState } from 'react'
import { Badge, Empty, Field, Modal, PageHead, money, uid } from '../components/ui'
import { team } from '../data/seed'
import { useAppDispatch, useAppSelector } from '../store'
import { deleteLead, saveLead } from '../store/crmSlice'
import { LEAD_STATUSES, Lead, LeadStatus } from '../types'
const blank = (): Lead => ({ id: uid(), name: '', company: '', email: '', phone: '', status: 'New', value: 0, owner: team[0] })
function LeadForm({ lead, onClose }: { lead: Lead; onClose: () => void }) {
  const d = useAppDispatch(); const [f, setF] = useState(lead); const [e, setE] = useState<Record<string, string>>({})
  const set = <K extends keyof Lead>(k: K, v: Lead[K]) => setF({ ...f, [k]: v })
  const submit = (ev: React.FormEvent) => { ev.preventDefault(); const er: Record<string, string> = {}
    if (!f.name.trim()) er.name = 'Name is required.'; if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = 'Enter a valid email address.'
    if (f.value < 0 || Number.isNaN(f.value)) er.value = 'Value must be 0 or more.'; setE(er)
    if (!Object.keys(er).length) { d(saveLead(f)); onClose() } }
  return <form onSubmit={submit} noValidate className="space-y-3">
    <Field label="Name" error={e.name}><input className="input" value={f.name} onChange={x => set('name', x.target.value)} /></Field>
    <Field label="Company"><input className="input" value={f.company} onChange={x => set('company', x.target.value)} /></Field>
    <Field label="Email" error={e.email}><input type="email" className="input" value={f.email} onChange={x => set('email', x.target.value)} /></Field>
    <Field label="Phone"><input className="input" value={f.phone} onChange={x => set('phone', x.target.value)} /></Field>
    <Field label="Deal value ($)" error={e.value}><input type="number" className="input" value={f.value} onChange={x => set('value', Number(x.target.value))} /></Field>
    <div className="grid grid-cols-2 gap-3"><Field label="Status"><select className="input" value={f.status} onChange={x => set('status', x.target.value as LeadStatus)}>{LEAD_STATUSES.map(s => <option key={s}>{s}</option>)}</select></Field>
    <Field label="Owner"><select className="input" value={f.owner} onChange={x => set('owner', x.target.value)}>{team.map(s => <option key={s}>{s}</option>)}</select></Field></div>
    <button className="btn w-full">Save lead</button></form>
}
export default function Leads() {
  const d = useAppDispatch(); const leads = useAppSelector(s => s.crm.leads)
  const [q, setQ] = useState(''); const [st, setSt] = useState(''); const [edit, setEdit] = useState<Lead | null>(null)
  const rows = leads.filter(l => (!st || l.status === st) && (l.name + l.company).toLowerCase().includes(q.toLowerCase()))
  return <><PageHead title="Leads" action={<button className="btn" onClick={() => setEdit(blank())}>New lead</button>} />
    <div className="mb-3 flex flex-wrap gap-2"><input aria-label="Search leads" placeholder="Search name or company" className="input max-w-xs" value={q} onChange={e => setQ(e.target.value)} />
      <select aria-label="Filter by status" className="input w-auto" value={st} onChange={e => setSt(e.target.value)}><option value="">All statuses</option>{LEAD_STATUSES.map(s => <option key={s}>{s}</option>)}</select></div>
    <div className="overflow-x-auto rounded-lg border border-line bg-white"><table className="w-full min-w-[640px] text-left text-sm">
      <thead className="border-b border-line text-ink/60"><tr>{['Lead', 'Status', 'Value', 'Owner', ''].map(h => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
      <tbody>{rows.map(l => <tr key={l.id} className="item-in border-b border-line transition-colors last:border-0 hover:bg-paper"><td className="px-4 py-3"><p className="font-medium">{l.name}</p><p className="text-ink/60">{l.company} · {l.email}</p></td>
        <td className="px-4"><Badge label={l.status} /></td><td className="px-4">{money(l.value)}</td><td className="px-4">{l.owner}</td>
        <td className="px-4 text-right"><button className="mr-3 underline" onClick={() => setEdit(l)}>Edit</button><button className="text-red-700 underline" onClick={() => confirm(`Delete ${l.name}?`) && d(deleteLead(l.id))}>Delete</button></td></tr>)}</tbody></table>
      {!rows.length && <Empty text="No leads match. Clear the filters or add a new lead." />}</div>
    {edit && <Modal title={leads.some(l => l.id === edit.id) ? 'Edit lead' : 'New lead'} onClose={() => setEdit(null)}><LeadForm lead={edit} onClose={() => setEdit(null)} /></Modal>}</>
}
