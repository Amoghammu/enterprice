import { useState } from 'react'
import { PageHead, money } from '../components/ui'
import { useAppDispatch, useAppSelector } from '../store'
import { moveDeal } from '../store/crmSlice'
import { STAGES, Stage } from '../types'
export default function Pipeline() {
  const [over, setOver] = useState<Stage | null>(null); const d = useAppDispatch(); const { deals, customers } = useAppSelector(s => s.crm)
  const name = (id: string) => customers.find(c => c.id === id)?.company ?? 'Unknown'
  return <><PageHead title="Sales pipeline" /><p className="mb-3 text-sm text-ink/60">Drag a deal to a new stage, or use the stage menu on touch devices.</p>
    <div className="flex gap-3 overflow-x-auto pb-3">{STAGES.map(stage => { const col = deals.filter(x => x.stage === stage)
      return <section key={stage} aria-label={stage} className={`w-72 shrink-0 rounded-lg p-3 transition-colors duration-200 ${over === stage ? 'bg-brand/20 ring-2 ring-brand' : 'bg-ink/5'}`} onDragOver={e => { e.preventDefault(); setOver(stage) }} onDragLeave={() => setOver(null)} onDrop={e => { setOver(null); d(moveDeal({ id: e.dataTransfer.getData('id'), stage })) }}>
        <h2 className="mb-3 flex justify-between font-bold">{stage}<span className="text-sm font-normal text-ink/60">{money(col.reduce((a, x) => a + x.value, 0))}</span></h2>
        <div className="space-y-2">{col.map(x => <article key={x.id} draggable onDragStart={e => e.dataTransfer.setData('id', x.id)} className="pop card-lift cursor-grab rounded-md border border-line bg-white p-3 active:cursor-grabbing">
          <p className="font-medium">{x.title}</p><p className="text-sm text-ink/60">{name(x.customerId)}</p><p className="mt-1 font-bold">{money(x.value)}</p>
          <select aria-label={`Move ${x.title}`} className="input mt-2 py-1" value={x.stage} onChange={e => d(moveDeal({ id: x.id, stage: e.target.value as Stage }))}>{STAGES.map(s => <option key={s}>{s}</option>)}</select></article>)}
          {!col.length && <p className="py-4 text-center text-sm text-ink/50">No deals</p>}</div></section> })}</div></>
}
