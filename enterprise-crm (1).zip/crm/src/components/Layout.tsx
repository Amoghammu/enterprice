import { NavLink, Outlet, useLocation } from 'react-router-dom'
const links = [['/', 'Dashboard'], ['/leads', 'Leads'], ['/pipeline', 'Pipeline'], ['/customers', 'Customers'], ['/tasks', 'Tasks'], ['/activities', 'Activities']]
export default function Layout() {
  const { pathname } = useLocation()
  return <div className="min-h-screen md:flex">
    <aside className="bg-ink text-white md:sticky md:top-0 md:h-screen md:w-56 md:shrink-0">
      <div className="px-5 py-4 text-lg font-bold">Northwind <span className="text-brand">CRM</span></div>
      <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0" aria-label="Main">
        {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `whitespace-nowrap rounded-md px-3 py-2 text-sm transition-all duration-200 md:hover:translate-x-1 ${isActive ? 'bg-brand font-medium text-ink' : 'text-white/80 hover:bg-white/10'}`}>{label}</NavLink>)}
      </nav></aside>
    <main key={pathname} className="page-in min-w-0 flex-1 p-4 md:p-8"><Outlet /></main></div>
}
