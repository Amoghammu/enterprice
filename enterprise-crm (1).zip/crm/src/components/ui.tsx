import { ReactNode, useEffect, useState } from 'react'
export function CountUp({ to, format = (n: number) => String(n) }: { to: number; format?: (n: number) => string }) {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return setV(to)
    let raf = 0; const t0 = performance.now()
    const tick = (t: number) => { const p = Math.min((t - t0) / 900, 1); setV(Math.round(to * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(tick) }
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf)
  }, [to])
  return <>{format(v)}</>
}
export const Spinner = () => <div role="status" aria-label="Loading" className="flex justify-center p-16"><div className="h-8 w-8 animate-spin rounded-full border-4 border-line border-t-brand" /></div>
export const ErrorBox = ({ msg, retry }: { msg: string; retry: () => void }) => <div role="alert" className="m-6 rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-800">{msg} <button className="underline" onClick={retry}>Try again</button></div>
export const Empty = ({ text }: { text: string }) => <p className="p-8 text-center text-sm text-ink/60">{text}</p>
const tone: Record<string, string> = { New: 'bg-sky-100 text-sky-800', Contacted: 'bg-amber-100 text-amber-800', Qualified: 'bg-violet-100 text-violet-800', Won: 'bg-emerald-100 text-emerald-800', Lost: 'bg-stone-200 text-stone-700', High: 'bg-red-100 text-red-800', Medium: 'bg-amber-100 text-amber-800', Low: 'bg-stone-200 text-stone-700' }
export const Badge = ({ label }: { label: string }) => <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${tone[label] ?? 'bg-stone-200'}`}>{label}</span>
export const Field = ({ label, error, children }: { label: string; error?: string; children: ReactNode }) => <label className="block text-sm"><span className="mb-1 block font-medium">{label}</span>{children}{error && <span role="alert" className="mt-1 block text-xs text-red-700">{error}</span>}</label>
export const Modal = ({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) => (
  <div className="fade-in fixed inset-0 z-50 flex items-end justify-center bg-ink/40 sm:items-center sm:p-4" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label={title} className="sheet-in max-h-[90vh] w-full overflow-auto rounded-t-xl bg-white p-6 sm:max-w-md sm:rounded-xl" onClick={e => e.stopPropagation()}>
      <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold">{title}</h2><button aria-label="Close" onClick={onClose} className="text-xl transition-transform hover:rotate-90">×</button></div>{children}</div></div>)
export const PageHead = ({ title, action }: { title: string; action?: ReactNode }) => <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><h1 className="text-2xl font-bold">{title}</h1>{action}</div>
export const money = (n: number) => '$' + n.toLocaleString('en-US')
export const uid = () => Math.random().toString(36).slice(2, 9)
