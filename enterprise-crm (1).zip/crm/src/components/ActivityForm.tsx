import { useState } from 'react'
import { useAppDispatch, useAppSelector } from '../store'
import { addActivity } from '../store/crmSlice'
import { ACTIVITY_TYPES, ActivityType } from '../types'
import { Field, uid } from './ui'
export default function ActivityForm({ customerId, onDone }: { customerId?: string; onDone: () => void }) {
  const d = useAppDispatch(); const customers = useAppSelector(s => s.crm.customers)
  const [f, setF] = useState({ type: 'Call' as ActivityType, customerId: customerId ?? customers[0]?.id ?? '', note: '', date: new Date().toISOString().slice(0, 10) })
  const [err, setErr] = useState('')
  const submit = (e: React.FormEvent) => { e.preventDefault(); if (f.note.trim().length < 3) return setErr('Add a short note (3+ characters).'); d(addActivity({ id: uid(), ...f, note: f.note.trim() })); onDone() }
  return <form onSubmit={submit} className="space-y-3" noValidate>
    <Field label="Type"><select className="input" value={f.type} onChange={e => setF({ ...f, type: e.target.value as ActivityType })}>{ACTIVITY_TYPES.map(t => <option key={t}>{t}</option>)}</select></Field>
    {!customerId && <Field label="Customer"><select className="input" value={f.customerId} onChange={e => setF({ ...f, customerId: e.target.value })}>{customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>}
    <Field label="Date"><input type="date" className="input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></Field>
    <Field label="Note" error={err}><textarea className="input" rows={3} value={f.note} onChange={e => setF({ ...f, note: e.target.value })} /></Field>
    <button className="btn w-full">Log activity</button></form>
}
