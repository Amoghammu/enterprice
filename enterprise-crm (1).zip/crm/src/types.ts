export const LEAD_STATUSES = ['New','Contacted','Qualified','Won','Lost'] as const
export const STAGES = ['Prospect','Proposal','Negotiation','Won'] as const
export const PRIORITIES = ['High','Medium','Low'] as const
export const ACTIVITY_TYPES = ['Call','Meeting','Email','Follow-up'] as const
export type LeadStatus = typeof LEAD_STATUSES[number]
export type Stage = typeof STAGES[number]
export type Priority = typeof PRIORITIES[number]
export type ActivityType = typeof ACTIVITY_TYPES[number]
export interface Lead { id: string; name: string; company: string; email: string; phone: string; status: LeadStatus; value: number; owner: string }
export interface Deal { id: string; title: string; customerId: string; value: number; stage: Stage }
export interface Customer { id: string; name: string; company: string; email: string; phone: string; city: string }
export interface Task { id: string; title: string; assignee: string; priority: Priority; due: string; done: boolean }
export interface Activity { id: string; type: ActivityType; customerId: string; note: string; date: string }
