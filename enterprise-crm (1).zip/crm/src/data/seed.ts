import type { Activity, Customer, Deal, Lead, Task } from '../types'
export const team = ['Asha Rao','Mateo Silva','Priya Nair','Tom Becker']
export const leads: Lead[] = [
 {id:'l1',name:'Ravi Menon',company:'Orbit Labs',email:'ravi@orbitlabs.io',phone:'+91 98450 11122',status:'New',value:12000,owner:'Asha Rao'},
 {id:'l2',name:'Elena Fox',company:'Fox & Daughters',email:'elena@foxd.com',phone:'+44 20 7946 0011',status:'Contacted',value:8500,owner:'Tom Becker'},
 {id:'l3',name:'Kenji Ito',company:'Hanabi Retail',email:'kenji@hanabi.jp',phone:'+81 3 5555 0101',status:'Qualified',value:34000,owner:'Priya Nair'},
 {id:'l4',name:'Sara Haddad',company:'Cedar Foods',email:'sara@cedar.co',phone:'+971 4 555 0199',status:'Won',value:21000,owner:'Mateo Silva'},
 {id:'l5',name:'Liam Burke',company:'Burke Logistics',email:'liam@burke.ie',phone:'+353 1 555 0133',status:'Lost',value:6000,owner:'Asha Rao'}]
export const customers: Customer[] = [
 {id:'c1',name:'Sara Haddad',company:'Cedar Foods',email:'sara@cedar.co',phone:'+971 4 555 0199',city:'Dubai'},
 {id:'c2',name:'Marta Klein',company:'Klein Studio',email:'marta@klein.de',phone:'+49 30 555 0142',city:'Berlin'},
 {id:'c3',name:'Anil Shah',company:'Shah Textiles',email:'anil@shah.in',phone:'+91 22 5555 0123',city:'Mumbai'}]
export const deals: Deal[] = [
 {id:'d1',title:'Cedar annual license',customerId:'c1',value:21000,stage:'Won'},
 {id:'d2',title:'Klein redesign retainer',customerId:'c2',value:15000,stage:'Proposal'},
 {id:'d3',title:'Shah ERP rollout',customerId:'c3',value:48000,stage:'Negotiation'},
 {id:'d4',title:'Klein onboarding',customerId:'c2',value:5000,stage:'Prospect'}]
export const tasks: Task[] = [
 {id:'t1',title:'Send revised quote to Shah Textiles',assignee:'Priya Nair',priority:'High',due:'2026-11-06',done:false},
 {id:'t2',title:'Prepare demo for Hanabi Retail',assignee:'Mateo Silva',priority:'Medium',due:'2026-11-10',done:false},
 {id:'t3',title:'Update lead scoring sheet',assignee:'Tom Becker',priority:'Low',due:'2026-11-02',done:true}]
export const activities: Activity[] = [
 {id:'a1',type:'Call',customerId:'c3',note:'Walked through ERP scope; asked for phased pricing.',date:'2026-11-02'},
 {id:'a2',type:'Email',customerId:'c2',note:'Sent proposal v2 with updated timeline.',date:'2026-10-30'},
 {id:'a3',type:'Meeting',customerId:'c1',note:'Contract signing and kickoff.',date:'2026-10-21'}]
export const revenue = [{m:'Jun',v:18},{m:'Jul',v:24},{m:'Aug',v:21},{m:'Sep',v:32},{m:'Oct',v:29},{m:'Nov',v:36}]
