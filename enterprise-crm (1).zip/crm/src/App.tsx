import { useEffect } from 'react'
import { Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import { ErrorBox, Spinner } from './components/ui'
import { useAppDispatch, useAppSelector } from './store'
import { loadCrm } from './store/crmSlice'
import Dashboard from './pages/Dashboard'
import Leads from './pages/Leads'
import Pipeline from './pages/Pipeline'
import Customers from './pages/Customers'
import Tasks from './pages/Tasks'
import Activities from './pages/Activities'
export default function App() {
  const d = useAppDispatch(); const { status, error } = useAppSelector(s => s.crm)
  useEffect(() => { d(loadCrm()) }, [d])
  return <Routes><Route element={<Layout />}>
    {['/', '/leads', '/pipeline', '/customers', '/tasks', '/activities'].map((p, i) => {
      const Page = [Dashboard, Leads, Pipeline, Customers, Tasks, Activities][i]
      return <Route key={p} path={p} element={status === 'failed' ? <ErrorBox msg={error ?? 'Something went wrong.'} retry={() => d(loadCrm())} /> : status === 'ready' ? <Page /> : <Spinner />} />
    })}</Route></Routes>
}
