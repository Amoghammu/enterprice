import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit'
import * as seed from '../data/seed'
import type { Activity, Customer, Deal, Lead, Stage, Task } from '../types'
export interface CrmState { leads: Lead[]; deals: Deal[]; customers: Customer[]; tasks: Task[]; activities: Activity[]; status: 'idle'|'loading'|'ready'|'failed'; error: string|null }
export const initialState: CrmState = { leads: [], deals: [], customers: [], tasks: [], activities: [], status: 'idle', error: null }
// Simulated API: swap for a real fetch call.
export const loadCrm = createAsyncThunk('crm/load', async () => {
  await new Promise(r => setTimeout(r, 600))
  return { leads: seed.leads, deals: seed.deals, customers: seed.customers, tasks: seed.tasks, activities: seed.activities }
})
const upsert = <T extends { id: string }>(list: T[], item: T) => { const i = list.findIndex(x => x.id === item.id); if (i >= 0) list[i] = item; else list.unshift(item) }
const slice = createSlice({ name: 'crm', initialState, reducers: {
  saveLead: (s, a: PayloadAction<Lead>) => { upsert(s.leads, a.payload) },
  deleteLead: (s, a: PayloadAction<string>) => { s.leads = s.leads.filter(l => l.id !== a.payload) },
  moveDeal: (s, a: PayloadAction<{ id: string; stage: Stage }>) => { const d = s.deals.find(x => x.id === a.payload.id); if (d) d.stage = a.payload.stage },
  saveTask: (s, a: PayloadAction<Task>) => { upsert(s.tasks, a.payload) },
  toggleTask: (s, a: PayloadAction<string>) => { const t = s.tasks.find(x => x.id === a.payload); if (t) t.done = !t.done },
  addActivity: (s, a: PayloadAction<Activity>) => { s.activities.unshift(a.payload) },
}, extraReducers: b => { b
  .addCase(loadCrm.pending, s => { s.status = 'loading'; s.error = null })
  .addCase(loadCrm.fulfilled, (s, a) => ({ ...s, ...a.payload, status: 'ready' as const }))
  .addCase(loadCrm.rejected, (s, a) => { s.status = 'failed'; s.error = a.error.message ?? 'Could not load data' }) } })
export const { saveLead, deleteLead, moveDeal, saveTask, toggleTask, addActivity } = slice.actions
export default slice.reducer
