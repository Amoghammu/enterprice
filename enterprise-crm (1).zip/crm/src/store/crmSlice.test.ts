import { describe, expect, it } from 'vitest'
import reducer, { initialState, saveLead, moveDeal, toggleTask } from './crmSlice'
const lead = { id: 'x', name: 'A', company: 'B', email: 'a@b.co', phone: '1', status: 'New' as const, value: 1, owner: 'Me' }
describe('crm slice', () => {
  it('adds then updates a lead', () => {
    let s = reducer(initialState, saveLead(lead))
    s = reducer(s, saveLead({ ...lead, status: 'Won' }))
    expect(s.leads).toHaveLength(1); expect(s.leads[0].status).toBe('Won')
  })
  it('moves a deal between stages', () => {
    const s = reducer({ ...initialState, deals: [{ id: 'd', title: 't', customerId: 'c', value: 1, stage: 'Prospect' }] }, moveDeal({ id: 'd', stage: 'Proposal' }))
    expect(s.deals[0].stage).toBe('Proposal')
  })
  it('toggles a task', () => {
    const s = reducer({ ...initialState, tasks: [{ id: 't', title: '', assignee: '', priority: 'Low', due: '', done: false }] }, toggleTask('t'))
    expect(s.tasks[0].done).toBe(true)
  })
})
